(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const toast = $("#toast");
  let toastTimer;

  function notify(message) {
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2400);
  }

  function formatNumber(value) {
    if (!Number.isFinite(value)) throw new Error("That result is outside the supported range.");
    if (Object.is(value, -0)) value = 0;
    return Number(value.toPrecision(12)).toString();
  }

  function evaluateExpression(source, variable = 0) {
    const normalized = source.replaceAll("×", "*").replaceAll("÷", "/").replaceAll("−", "-").replaceAll("π", "pi").trim();
    const tokens = normalized.match(/(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?|[a-z_]+|[()+\-*/^,]/gi) || [];
    if (!normalized || tokens.join("") !== normalized.replace(/\s/g, "")) throw new Error("Check the expression and try again.");
    let index = 0;
    const peek = () => tokens[index];
    const take = () => tokens[index++];
    function primary() {
      if (peek() === "(") {
        take();
        const value = sum();
        if (take() !== ")") throw new Error("Add a closing parenthesis.");
        return value;
      }
      const token = take();
      if (token === undefined) throw new Error("Check the expression and try again.");
      if (/^(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(token)) return Number(token);
      const name = token.toLowerCase();
      if (name === "x") return variable;
      if (name === "pi") return Math.PI;
      if (name === "e") return Math.E;
      if (peek() !== "(") throw new Error(`Use ${name}(…) for this function.`);
      take();
      const first = sum();
      let second;
      if (peek() === ",") { take(); second = sum(); }
      if (take() !== ")") throw new Error("Add a closing parenthesis.");
      const oneArgument = {
        sin: Math.sin, cos: Math.cos, tan: Math.tan, asin: Math.asin, acos: Math.acos, atan: Math.atan,
        sinh: Math.sinh, cosh: Math.cosh, tanh: Math.tanh, asinh: Math.asinh, acosh: Math.acosh, atanh: Math.atanh,
        sqrt: Math.sqrt, abs: Math.abs, exp: Math.exp, ln: Math.log, log: Math.log10, log10: Math.log10,
        floor: Math.floor, ceil: Math.ceil, round: Math.round, sign: Math.sign, csc: (x) => 1 / Math.sin(x),
        sec: (x) => 1 / Math.cos(x), cot: (x) => 1 / Math.tan(x)
      };
      if (name === "pow" && second !== undefined) return Math.pow(first, second);
      if (name === "min" && second !== undefined) return Math.min(first, second);
      if (name === "max" && second !== undefined) return Math.max(first, second);
      if (name === "fact") {
        if (!Number.isInteger(first) || first < 0 || first > 170) throw new Error("fact(x) needs a whole number from 0 to 170.");
        let value = 1; for (let n = 2; n <= first; n++) value *= n; return value;
      }
      if (second !== undefined || !oneArgument[name]) throw new Error(`Unknown function: ${name}`);
      return oneArgument[name](first);
    }
    function power() {
      const value = primary();
      if (peek() === "^") { take(); return Math.pow(value, unary()); }
      return value;
    }
    function unary() {
      if (peek() === "+") { take(); return unary(); }
      if (peek() === "-") { take(); return -unary(); }
      return power();
    }
    function product() {
      let value = unary();
      while (peek() === "*" || peek() === "/") {
        const operator = take(); const right = unary();
        value = operator === "*" ? value * right : value / right;
      }
      return value;
    }
    function sum() {
      let value = product();
      while (peek() === "+" || peek() === "-") {
        const operator = take(); const right = product();
        value = operator === "+" ? value + right : value - right;
      }
      return value;
    }
    const result = sum();
    if (index !== tokens.length) throw new Error("Check the expression and try again.");
    if (!Number.isFinite(result)) throw new Error("That result is outside the supported range.");
    return result;
  }

  const storage = {
    read(key, fallback) {
      try {
        const value = JSON.parse(localStorage.getItem(key) || "null");
        return value ?? fallback;
      } catch { return fallback; }
    },
    write(key, value) {
      try { localStorage.setItem(key, JSON.stringify(value)); }
      catch { notify("This browser couldn't save local history."); }
    }
  };

  const themes = {
    soft: { ink: "#463452", muted: "#786889", plum: "#8a66a1", rose: "#f2a9c8", pink: "#f9d9e7", lilac: "#e6daf4", lavender: "#f5effa", blue: "#c5eaf4", mint: "#d9f0e2", white: "#fffdfd", line: "#e8deed" },
    ocean: { ink: "#183e50", muted: "#527989", plum: "#167c8c", rose: "#75cad1", pink: "#d1f0ee", lilac: "#c6e9ec", lavender: "#e9f7f6", blue: "#a8dfee", mint: "#bde9d9", white: "#faffff", line: "#b9dfe1" },
    neon: { ink: "#f4f0ff", muted: "#aaa3c8", plum: "#c26dff", rose: "#ff4fa3", pink: "#332344", lilac: "#302451", lavender: "#111322", blue: "#2b405a", mint: "#224541", white: "#1b1d30", line: "#40395c" },
    terminal: { ink: "#a7f5b5", muted: "#62b97a", plum: "#55ee79", rose: "#226f3b", pink: "#163d27", lilac: "#17472d", lavender: "#07170e", blue: "#164a47", mint: "#17472d", white: "#0b2113", line: "#28643b" },
    paper: { ink: "#483624", muted: "#887458", plum: "#986b3e", rose: "#d6ad7c", pink: "#f3e3ca", lilac: "#e9d8b9", lavender: "#f5eddd", blue: "#d4e0d8", mint: "#dce5cb", white: "#fffaf0", line: "#ddcfb6" },
    arcade: { ink: "#27154f", muted: "#66549a", plum: "#713aff", rose: "#ff56ac", pink: "#ffd0f0", lilac: "#d9c7ff", lavender: "#f2eaff", blue: "#79e8ff", mint: "#a4f7d2", white: "#fffaff", line: "#bba5ed" },
    aurora: { ink: "#25445a", muted: "#627e87", plum: "#79559b", rose: "#d4b7e8", pink: "#d9eee6", lilac: "#e7d9f1", lavender: "#e9f4f1", blue: "#c7e7ed", mint: "#c8ebd9", white: "#fbfffe", line: "#d3e5e3" },
    mono: { ink: "#29343e", muted: "#687580", plum: "#46525d", rose: "#87939d", pink: "#e3e7ea", lilac: "#e3e7ea", lavender: "#eceff1", blue: "#dbe3e9", mint: "#dfe8e3", white: "#fbfcfd", line: "#d3d9de" }
  };
  let preferences = storage.read("apex-mobile-preferences", { preset: "soft", style: "soft", custom: null, sounds: true, soundStyle: "soft" });
  if (!preferences || typeof preferences !== "object") preferences = { preset: "soft", style: "soft", custom: null, sounds: true, soundStyle: "soft" };
  const legacyPresets = { lavender: "soft", sky: "ocean", forest: "paper", midnight: "neon" };
  preferences.preset = legacyPresets[preferences.preset] || preferences.preset || "soft";
  if (!themes[preferences.style]) preferences.style = preferences.preset === "custom" ? "soft" : preferences.preset;
  if (typeof preferences.sounds !== "boolean") preferences.sounds = true;
  if (!["soft", "mechanical", "bubble", "arcade"].includes(preferences.soundStyle)) preferences.soundStyle = "soft";
  const rootStyle = document.documentElement.style;

  function parseHex(value, fallback) { return /^#[\da-f]{6}$/i.test(value || "") ? value : fallback; }
  function mixHex(first, second, firstWeight) {
    const a = first.match(/[\da-f]{2}/gi).map((part) => Number.parseInt(part, 16));
    const b = second.match(/[\da-f]{2}/gi).map((part) => Number.parseInt(part, 16));
    return `#${a.map((value, index) => Math.round(value * firstWeight + b[index] * (1 - firstWeight)).toString(16).padStart(2, "0")).join("")}`;
  }
  function customPalette(colors) {
    const background = parseHex(colors.background, themes.soft.lavender);
    const card = parseHex(colors.card, themes.soft.white);
    const text = parseHex(colors.text, themes.soft.ink);
    const accent = parseHex(colors.accent, themes.soft.plum);
    const cool = parseHex(colors.cool, themes.soft.blue);
    const rose = mixHex(accent, card, .55);
    return {
      ink: text,
      muted: mixHex(text, background, .58),
      plum: accent,
      rose,
      pink: mixHex(rose, card, .45),
      lilac: mixHex(accent, background, .18),
      lavender: background,
      blue: cool,
      mint: mixHex(cool, card, .38),
      white: card,
      line: mixHex(accent, background, .2)
    };
  }
  function activeStyle() {
    return preferences.preset === "custom" ? (themes[preferences.style] ? preferences.style : "soft") : preferences.preset;
  }
  function applyPalette(palette) {
    for (const [name, value] of Object.entries(palette)) rootStyle.setProperty(`--${name}`, value);
    const style = activeStyle();
    document.documentElement.dataset.theme = style;
    document.querySelector('meta[name="theme-color"]').content = palette.lavender;
    $("#style-name").textContent = preferences.preset === "custom" ? `Custom · ${style[0].toUpperCase()}${style.slice(1)}` : ({ soft: "Cozy Pink", ocean: "Ocean Glass", neon: "Midnight Neon", terminal: "Retro Terminal", paper: "Warm Paper", arcade: "Arcade", aurora: "Aurora Glass", mono: "Monochrome Studio" })[style];
  }
  function paletteForPreferences() {
    return preferences.preset === "custom" && preferences.custom
      ? customPalette(preferences.custom)
      : themes[preferences.preset] || themes.soft;
  }
  function savePreferences() {
    storage.write("apex-mobile-preferences", preferences);
    applyPalette(paletteForPreferences());
    $("#click-sounds").checked = preferences.sounds;
    $("#click-sound-style").value = preferences.soundStyle;
  }
  applyPalette(paletteForPreferences());

  let audioContext = null;
  function playClickSound() {
    if (!preferences.sounds) return;
    try {
      const AudioContextType = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextType) return;
      audioContext ||= new AudioContextType();
      if (audioContext.state === "suspended") audioContext.resume();
      const now = audioContext.currentTime;
      const oscillator = audioContext.createOscillator();
      const volume = audioContext.createGain();
      const soundStyle = preferences.soundStyle || "soft";
      const settings = {
        soft: { type: "sine", start: 1080, end: 560, duration: .04, gain: .032 },
        mechanical: { type: "square", start: 430, end: 260, duration: .022, gain: .018 },
        bubble: { type: "sine", start: 520, end: 1320, duration: .075, gain: .035 },
        arcade: { type: "triangle", start: 760, end: 1120, duration: .055, gain: .028 }
      }[soundStyle] || { type: "sine", start: 1080, end: 560, duration: .04, gain: .032 };
      oscillator.type = settings.type;
      oscillator.frequency.setValueAtTime(settings.start, now);
      oscillator.frequency.exponentialRampToValueAtTime(settings.end, now + settings.duration * .75);
      volume.gain.setValueAtTime(settings.gain, now);
      volume.gain.exponentialRampToValueAtTime(.001, now + settings.duration);
      oscillator.connect(volume); volume.connect(audioContext.destination);
      oscillator.start(now); oscillator.stop(now + settings.duration + .005);
    } catch { /* Audio is optional; the controls remain usable without it. */ }
  }
  document.addEventListener("click", (event) => {
    if (event.target.closest("button:not(:disabled)")) playClickSound();
  });

  const themeDialog = $("#theme-dialog");
  const themePreset = $("#theme-preset");
  const customColors = $("#custom-colors");
  const colorInputs = {
    background: $("#custom-background"), card: $("#custom-card"), text: $("#custom-text"),
    accent: $("#custom-accent"), cool: $("#custom-cool")
  };
  function fillCustomInputs(colors) {
    colorInputs.background.value = colors.background;
    colorInputs.card.value = colors.card;
    colorInputs.text.value = colors.text;
    colorInputs.accent.value = colors.accent;
    colorInputs.cool.value = colors.cool;
  }
  function setInputsFromPalette(palette) {
    fillCustomInputs({ background: palette.lavender, card: palette.white, text: palette.ink, accent: palette.plum, cool: palette.blue });
  }
  $("#theme-button").addEventListener("click", () => {
    themePreset.value = preferences.preset;
    const currentPalette = paletteForPreferences();
    const custom = preferences.custom || { background: currentPalette.lavender, card: currentPalette.white, text: currentPalette.ink, accent: currentPalette.plum, cool: currentPalette.blue };
    fillCustomInputs(custom);
    $("#click-sounds").checked = preferences.sounds;
    $("#click-sound-style").value = preferences.soundStyle;
    $("#custom-style").value = preferences.style || "soft";
    customColors.hidden = themePreset.value !== "custom";
    $("#custom-style-row").hidden = themePreset.value !== "custom";
    $("#custom-style").hidden = themePreset.value !== "custom";
    if (typeof themeDialog.showModal === "function") themeDialog.showModal();
  });
  themePreset.addEventListener("change", () => {
    customColors.hidden = themePreset.value !== "custom";
    $("#custom-style-row").hidden = themePreset.value !== "custom";
    $("#custom-style").hidden = themePreset.value !== "custom";
    if (themePreset.value !== "custom") setInputsFromPalette(themes[themePreset.value] || themes.soft);
  });
  $("#close-theme").addEventListener("click", () => themeDialog.close());
  $("#cancel-theme").addEventListener("click", () => themeDialog.close());
  $("#theme-form").addEventListener("submit", (event) => {
    event.preventDefault();
    preferences.preset = themePreset.value;
    preferences.style = themePreset.value === "custom" ? $("#custom-style").value : themePreset.value;
    preferences.soundStyle = $("#click-sound-style").value;
    preferences.sounds = $("#click-sounds").checked;
    if (preferences.preset === "custom") {
      preferences.custom = Object.fromEntries(Object.entries(colorInputs).map(([key, input]) => [key, input.value]));
    }
    savePreferences();
    themeDialog.close();
    notify("Apex preferences saved on this device.");
  });
  $("#export-theme").addEventListener("click", () => {
    const palette = Object.fromEntries(Object.entries(colorInputs).map(([key, input]) => [key, input.value]));
    downloadJson("apex-theme.json", { version: 1, preferences: { preset: themePreset.value, style: $("#custom-style").value, custom: palette, sounds: $("#click-sounds").checked, soundStyle: $("#click-sound-style").value } });
  });
  $("#import-theme").addEventListener("click", () => $("#theme-file").click());
  $("#theme-file").addEventListener("change", async () => {
    const file = $("#theme-file").files?.[0]; if (!file) return;
    try {
      const data = JSON.parse(await file.text()), incoming = data.preferences || data;
      if (!incoming || !(incoming.preset === "custom" || themes[incoming.preset])) throw new Error("Choose a valid Apex theme file.");
      if (incoming.preset === "custom") {
        const colors = incoming.custom;
        if (!colors || !["background", "card", "text", "accent", "cool"].every((key) => /^#[\da-f]{6}$/i.test(colors[key] || ""))) throw new Error("The custom theme needs five valid hex colors.");
      }
      preferences.preset = incoming.preset;
      preferences.style = themes[incoming.style] ? incoming.style : (themes[incoming.preset] ? incoming.preset : "soft");
      preferences.custom = incoming.preset === "custom" ? incoming.custom : preferences.custom;
      preferences.sounds = typeof incoming.sounds === "boolean" ? incoming.sounds : preferences.sounds;
      preferences.soundStyle = ["soft", "mechanical", "bubble", "arcade"].includes(incoming.soundStyle) ? incoming.soundStyle : "soft";
      savePreferences(); themePreset.value = preferences.preset; $("#custom-style").value = preferences.style;
      if (preferences.custom) fillCustomInputs(preferences.custom);
      customColors.hidden = preferences.preset !== "custom"; $("#custom-style-row").hidden = preferences.preset !== "custom"; $("#custom-style").hidden = preferences.preset !== "custom";
      themeDialog.close(); notify("Theme imported and saved on this device.");
    } catch (error) { notify(error.message || "That theme file couldn't be imported."); }
    $("#theme-file").value = "";
  });
  const helpDialog = $("#help-dialog");
  $("#help-button").addEventListener("click", () => { if (typeof helpDialog.showModal === "function") helpDialog.showModal(); });
  $("#close-help").addEventListener("click", () => helpDialog.close());
  helpDialog.addEventListener("click", (event) => { if (event.target === helpDialog) helpDialog.close(); });

  let history = storage.read("apex-mobile-history", []);
  if (!Array.isArray(history)) history = [];
  history = history.filter((row) => row && typeof row.expression === "string" && typeof row.answer === "string").slice(0, 30);
  let expression = "0";
  let memory = 0;
  let replaceOnDigit = true;

  const display = $("#calc-display");
  const caption = $("#calc-caption");

  function renderCalc() {
    display.textContent = expression;
    $("#memory-indicator").textContent = memory === 0 ? "Memory empty" : "Memory saved";
  }

  function addHistory(source, answer) {
    history.unshift({ expression: source, answer, time: Date.now() });
    history = history.slice(0, 30);
    storage.write("apex-mobile-history", history);
    renderHistory();
    renderRecent();
  }

  function calculate() {
    const source = expression;
    try {
      const result = formatNumber(evaluateExpression(source));
      caption.textContent = source;
      expression = result;
      replaceOnDigit = true;
      renderCalc();
      addHistory(source, result);
    } catch (error) {
      notify(error.message || "Check the expression and try again.");
    }
  }

  function appendValue(value) {
    const isDigit = /\d|\./.test(value);
    if (replaceOnDigit && isDigit) {
      expression = value === "." ? "0." : value;
      caption.textContent = "Apex calculator";
      replaceOnDigit = false;
      renderCalc();
      return;
    }
    const isOperator = ["+", "−", "×", "÷"].includes(value);
    if (isOperator && /[+−×÷]$/.test(expression)) expression = expression.slice(0, -1);
    if (value === ".") {
      const tail = expression.split(/[+−×÷]/).at(-1) || "";
      if (tail.includes(".")) return;
      if (!tail) expression += "0";
    }
    if (expression === "0" && value !== "." && !isOperator) expression = "";
    expression += value;
    replaceOnDigit = false;
    renderCalc();
  }

  function calcAction(action) {
    if (action === "clear") {
      expression = "0"; caption.textContent = "Apex calculator"; replaceOnDigit = true; renderCalc(); return;
    }
    if (action === "backspace") {
      expression = expression.length > 1 ? expression.slice(0, -1) : "0"; replaceOnDigit = false; renderCalc(); return;
    }
    if (action === "equals") return calculate();
    if (action === "sign" || action === "percent" || action === "square" || action === "sqrt" || action === "reciprocal" || action === "memory-add") {
      try {
        const current = evaluateExpression(expression);
        let next = current;
        if (action === "sign") next = -current;
        if (action === "percent") next = current / 100;
        if (action === "square") next = current * current;
        if (action === "sqrt") next = Math.sqrt(current);
        if (action === "reciprocal") next = 1 / current;
        if (action === "memory-add") { memory += current; notify("Added to memory."); renderCalc(); return; }
        caption.textContent = expression;
        expression = formatNumber(next);
        replaceOnDigit = true;
        renderCalc();
      } catch (error) { notify(error.message || "That operation isn't available for this value."); }
      return;
    }
    if (action === "memory-clear") { memory = 0; renderCalc(); notify("Memory cleared."); return; }
    if (action === "memory-recall") { expression = formatNumber(memory); replaceOnDigit = true; renderCalc(); return; }
  }

  $("#keypad").addEventListener("click", (event) => {
    const button = event.target.closest("button");
    if (!button) return;
    if (button.dataset.action) calcAction(button.dataset.action);
    else if (button.dataset.value) appendValue(button.dataset.value);
  });

  document.addEventListener("keydown", (event) => {
    if (event.ctrlKey && /^[1-8]$/.test(event.key)) {
      const target = tabButtons[Number(event.key) - 1];
      if (target) { showPanel(target.dataset.panel); target.focus(); event.preventDefault(); }
      return;
    }
    if (event.key === "?" && !/^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement?.tagName || "")) {
      if (typeof helpDialog.showModal === "function") helpDialog.showModal();
      return;
    }
    const activePanel = $(".panel.active");
    if (activePanel?.id !== "panel-standard" || /^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement?.tagName || "")) return;
    if (document.activeElement instanceof HTMLButtonElement && (event.key === "Enter" || event.key === " ")) return;
    let handled = true;
    if (/^[0-9.]$/.test(event.key)) appendValue(event.key);
    else if (event.key === "Enter" || event.key === "=") calculate();
    else if (event.key === "Backspace") calcAction("backspace");
    else if (event.key === "Escape") calcAction("clear");
    else if (event.key === "+") appendValue("+");
    else if (event.key === "-") appendValue("−");
    else if (event.key === "*") appendValue("×");
    else if (event.key === "/") appendValue("÷");
    else handled = false;
    if (handled) { playClickSound(); event.preventDefault(); }
  });

  function renderHistory() {
    const container = $("#history-list");
    container.replaceChildren();
    if (!history.length) {
      container.innerHTML = '<div class="empty-state"><span aria-hidden="true">♡</span><h2>No calculations yet.</h2><p>Try the Standard panel and your recent answers will appear here.</p></div>';
      return;
    }
    for (const row of history) {
      const item = document.createElement("button");
      item.type = "button";
      item.className = "history-item";
      item.innerHTML = '<span class="history-expression"></span><strong class="history-answer"></strong>';
      item.querySelector(".history-expression").textContent = row.expression;
      item.querySelector(".history-answer").textContent = row.answer;
      item.addEventListener("click", () => { expression = row.answer; caption.textContent = row.expression; replaceOnDigit = true; renderCalc(); showPanel("standard"); });
      container.append(item);
    }
  }

  function renderRecent() {
    const container = $("#recent-mini");
    container.replaceChildren();
    if (!history.length) { const note = document.createElement("p"); note.className = "empty-note"; note.textContent = "Your recent answers will show up here."; container.append(note); return; }
    for (const row of history.slice(0, 3)) {
      const item = document.createElement("div");
      item.className = "mini-entry";
      const expr = document.createElement("span"); expr.textContent = row.expression;
      const answer = document.createElement("strong"); answer.textContent = row.answer;
      item.append(expr, answer); container.append(item);
    }
  }

  $("#clear-history").addEventListener("click", () => {
    history = [];
    storage.write("apex-mobile-history", history);
    renderHistory(); renderRecent(); notify("Local calculation history cleared.");
  });

  const tabButtons = $$(".mode-tab");
  const panels = $$(".panel");
  function showPanel(name) {
    for (const button of tabButtons) {
      const selected = button.dataset.panel === name;
      button.classList.toggle("active", selected);
      button.setAttribute("aria-selected", String(selected));
      button.tabIndex = selected ? 0 : -1;
      if (selected && window.matchMedia("(max-width: 760px)").matches) button.scrollIntoView({ block: "nearest", inline: "center", behavior: "smooth" });
    }
    for (const panel of panels) {
      const selected = panel.id === `panel-${name}`;
      panel.hidden = !selected;
      panel.classList.toggle("active", selected);
    }
  }
  for (const button of tabButtons) button.addEventListener("click", () => showPanel(button.dataset.panel));
  $$('[data-go="history"]').forEach((button) => button.addEventListener("click", () => showPanel("history")));
  for (const button of tabButtons) {
    button.addEventListener("keydown", (event) => {
      if (!["ArrowRight", "ArrowLeft", "Home", "End"].includes(event.key)) return;
      event.preventDefault();
      const current = tabButtons.indexOf(button);
      const next = event.key === "Home" ? 0 : event.key === "End" ? tabButtons.length - 1 : (current + (event.key === "ArrowRight" ? 1 : -1) + tabButtons.length) % tabButtons.length;
      tabButtons[next].focus();
      showPanel(tabButtons[next].dataset.panel);
    });
  }

  const sciValue = $("#sci-value");
  const sciAngle = $("#angle-mode");
  const sciResult = $("#sci-result");
  $("#sci-grid").addEventListener("click", (event) => {
    const button = event.target.closest("[data-sci]");
    if (!button) return;
    const operation = button.dataset.sci;
    const input = Number(sciValue.value);
    const radians = sciAngle.value === "deg" ? input * Math.PI / 180 : input;
    const angleOut = (value) => sciAngle.value === "deg" ? value * 180 / Math.PI : value;
    let result;
    if (operation === "pi") result = Math.PI;
    else if (operation === "e") result = Math.E;
    else if (operation === "sin") result = Math.sin(radians);
    else if (operation === "cos") result = Math.cos(radians);
    else if (operation === "tan") result = Math.tan(radians);
    else if (operation === "asin") result = angleOut(Math.asin(input));
    else if (operation === "acos") result = angleOut(Math.acos(input));
    else if (operation === "atan") result = angleOut(Math.atan(input));
    else if (operation === "sqrt") result = Math.sqrt(input);
    else if (operation === "square") result = input * input;
    else if (operation === "log") result = Math.log10(input);
    else if (operation === "ln") result = Math.log(input);
    else if (operation === "reciprocal") result = 1 / input;
    else if (operation === "factorial") {
      if (!Number.isInteger(input) || input < 0 || input > 170) { notify("Factorial needs a whole number from 0 to 170."); return; }
      result = 1; for (let n = 2; n <= input; n++) result *= n;
    }
    try { sciResult.textContent = formatNumber(result); }
    catch (error) { sciResult.textContent = "—"; notify(error.message || "That result is not defined."); }
  });

  const programmerValue = $("#programmer-value");
  const programmerBase = $("#programmer-base");
  function parseInteger(text, base) {
    let source = text.trim().replaceAll("_", "");
    if (!source) throw new Error("Enter an integer value.");
    let negative = false;
    if (source.startsWith("-") || source.startsWith("+")) { negative = source[0] === "-"; source = source.slice(1); }
    if (base === 16 && /^0x/i.test(source)) source = source.slice(2);
    if (base === 2 && /^0b/i.test(source)) source = source.slice(2);
    if (base === 8 && /^0o/i.test(source)) source = source.slice(2);
    const patterns = { 2: /^[01]+$/, 8: /^[0-7]+$/, 10: /^\d+$/, 16: /^[\da-f]+$/i };
    if (!patterns[base].test(source)) throw new Error(`That isn't a valid base-${base} integer.`);
    const prefix = base === 16 ? "0x" : base === 8 ? "0o" : base === 2 ? "0b" : "";
    const value = BigInt(prefix + source);
    const signed = negative ? -value : value;
    if (signed < -(1n << 63n) || signed > (1n << 64n) - 1n) throw new Error("Use an integer between −2⁶³ and 2⁶⁴−1.");
    return signed;
  }
  function updateProgrammer() {
    try {
      const value = parseInteger(programmerValue.value, Number(programmerBase.value));
      $("#base-bin").textContent = value.toString(2);
      $("#base-oct").textContent = value.toString(8);
      $("#base-dec").textContent = value.toString(10);
      $("#base-hex").textContent = value.toString(16).toUpperCase();
    } catch (error) {
      for (const id of ["#base-bin", "#base-oct", "#base-dec", "#base-hex"]) $(id).textContent = "—";
      if (programmerValue.value.trim()) $("#base-dec").textContent = error.message;
    }
    updateBitwise();
  }
  programmerValue.addEventListener("input", updateProgrammer);
  programmerBase.addEventListener("change", updateProgrammer);
  function updateBitwise() {
    try {
      const left = BigInt($("#bitwise-a").value.trim());
      const right = BigInt($("#bitwise-b").value.trim());
      const operation = $("#bitwise-op").value;
      let result;
      if (operation === "and") result = left & right;
      else if (operation === "or") result = left | right;
      else if (operation === "xor") result = left ^ right;
      else if (operation === "shl") result = left << (right < 0n ? 0n : right > 63n ? 63n : right);
      else result = left >> (right < 0n ? 0n : right > 63n ? 63n : right);
      $("#bitwise-result").textContent = result.toString();
    } catch { $("#bitwise-result").textContent = "Enter integers"; }
  }
  $("#bitwise-a").addEventListener("input", updateBitwise);
  $("#bitwise-b").addEventListener("input", updateBitwise);
  $("#bitwise-op").addEventListener("change", updateBitwise);

  const unitSets = {
    Length: { m: 1, km: 1000, cm: .01, mm: .001, mile: 1609.344, ft: .3048, in: .0254 },
    Mass: { kg: 1, g: .001, lb: .45359237, oz: .028349523125 },
    Temperature: { "°C": 1, "°F": 1, K: 1 }
  };
  const categorySelect = $("#convert-category");
  const fromSelect = $("#convert-from");
  const toSelect = $("#convert-to");
  function fillUnits() {
    const units = Object.keys(unitSets[categorySelect.value]);
    const oldFrom = fromSelect.value; const oldTo = toSelect.value;
    fromSelect.replaceChildren(); toSelect.replaceChildren();
    for (const unit of units) {
      fromSelect.add(new Option(unit, unit)); toSelect.add(new Option(unit, unit));
    }
    fromSelect.value = units.includes(oldFrom) ? oldFrom : units[0];
    toSelect.value = units.includes(oldTo) ? oldTo : units[Math.min(1, units.length - 1)];
    updateConversion();
  }
  function convertTemperature(value, from, to) {
    const celsius = from === "°C" ? value : from === "°F" ? (value - 32) * 5 / 9 : value - 273.15;
    return to === "°C" ? celsius : to === "°F" ? celsius * 9 / 5 + 32 : celsius + 273.15;
  }
  function updateConversion() {
    const value = Number($("#convert-value").value);
    if (!Number.isFinite(value)) { $("#convert-result").textContent = "Enter a number"; return; }
    const from = fromSelect.value; const to = toSelect.value;
    const result = categorySelect.value === "Temperature" ? convertTemperature(value, from, to) : value * unitSets[categorySelect.value][from] / unitSets[categorySelect.value][to];
    try { $("#convert-result").textContent = `${formatNumber(result)} ${to}`; }
    catch { $("#convert-result").textContent = "—"; }
  }
  categorySelect.addEventListener("change", fillUnits);
  fromSelect.addEventListener("change", updateConversion);
  toSelect.addEventListener("change", updateConversion);
  $("#convert-value").addEventListener("input", updateConversion);

  const labTabs = $$(".lab-tab");
  const mathPanes = $$(".math-pane");
  function showMathPane(name) {
    for (const button of labTabs) {
      const selected = button.dataset.labTab === name;
      button.classList.toggle("active", selected);
      button.setAttribute("aria-selected", String(selected));
      button.tabIndex = selected ? 0 : -1;
    }
    for (const pane of mathPanes) pane.hidden = pane.id !== `math-pane-${name}`;
    if (name === "graph") requestAnimationFrame(drawGraph);
  }
  for (const button of labTabs) button.addEventListener("click", () => showMathPane(button.dataset.labTab));
  for (const button of labTabs) button.addEventListener("keydown", (event) => {
    if (!["ArrowRight", "ArrowLeft", "Home", "End"].includes(event.key)) return;
    event.preventDefault();
    const current = labTabs.indexOf(button);
    const next = event.key === "Home" ? 0 : event.key === "End" ? labTabs.length - 1 : (current + (event.key === "ArrowRight" ? 1 : -1) + labTabs.length) % labTabs.length;
    labTabs[next].focus(); showMathPane(labTabs[next].dataset.labTab);
  });

  const graphCanvas = $("#graph-canvas");
  function drawGraph() {
    if (!graphCanvas || $("#panel-math-lab").hidden || $("#math-pane-graph").hidden) return;
    const rect = graphCanvas.getBoundingClientRect();
    if (rect.width < 20 || rect.height < 20) return;
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    graphCanvas.width = Math.round(rect.width * ratio); graphCanvas.height = Math.round(rect.height * ratio);
    const ctx = graphCanvas.getContext("2d"); ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    const width = rect.width, height = rect.height, pad = { left: 45, right: 18, top: 18, bottom: 34 };
    const plotWidth = width - pad.left - pad.right, plotHeight = height - pad.top - pad.bottom;
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue("--white").trim() || "#fff"; ctx.fillRect(0, 0, width, height);
    const expressionText = $("#graph-expression").value.trim();
    const xMin = Number($("#graph-min").value), xMax = Number($("#graph-max").value);
    const status = $("#graph-status");
    if (!expressionText || !Number.isFinite(xMin) || !Number.isFinite(xMax) || xMin >= xMax) { status.textContent = "Enter a function and an increasing x interval."; return; }
    const samples = [];
    try {
      for (let i = 0; i <= Math.max(400, Math.floor(plotWidth * 2)); i++) {
        const x = xMin + (xMax - xMin) * i / Math.max(400, Math.floor(plotWidth * 2));
        const y = evaluateExpression(expressionText, x);
        samples.push({ x, y: Number.isFinite(y) && Math.abs(y) < 1e8 ? y : NaN });
      }
    } catch (error) { status.textContent = error.message || "Could not plot this function."; return; }
    const finite = samples.filter((point) => Number.isFinite(point.y)).map((point) => point.y);
    if (!finite.length) { status.textContent = "This function has no finite values in that interval."; return; }
    let yMin = Math.min(...finite), yMax = Math.max(...finite);
    if (yMax === yMin) { yMin -= 1; yMax += 1; }
    const yPad = (yMax - yMin) * .08; yMin -= yPad; yMax += yPad;
    const px = (x) => pad.left + (x - xMin) / (xMax - xMin) * plotWidth;
    const py = (y) => pad.top + (yMax - y) / (yMax - yMin) * plotHeight;
    const ink = getComputedStyle(document.documentElement).getPropertyValue("--muted").trim() || "#777";
    const line = getComputedStyle(document.documentElement).getPropertyValue("--line").trim() || "#ddd";
    ctx.font = "11px system-ui"; ctx.textAlign = "center"; ctx.textBaseline = "top"; ctx.strokeStyle = line; ctx.fillStyle = ink; ctx.lineWidth = 1;
    for (let i = 0; i <= 5; i++) {
      const x = pad.left + plotWidth * i / 5, y = pad.top + plotHeight * i / 5;
      ctx.beginPath(); ctx.moveTo(x, pad.top); ctx.lineTo(x, pad.top + plotHeight); ctx.moveTo(pad.left, y); ctx.lineTo(pad.left + plotWidth, y); ctx.stroke();
      ctx.fillText(formatNumber(xMin + (xMax - xMin) * i / 5), x, height - pad.bottom + 7);
    }
    ctx.textAlign = "right"; ctx.textBaseline = "middle";
    for (let i = 0; i <= 5; i++) ctx.fillText(formatNumber(yMax - (yMax - yMin) * i / 5), pad.left - 7, pad.top + plotHeight * i / 5);
    ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue("--plum").trim() || "#805c99"; ctx.lineWidth = 2.5; ctx.lineJoin = "round"; ctx.beginPath();
    let drawing = false;
    for (const point of samples) {
      if (!Number.isFinite(point.y) || point.y < yMin - (yMax-yMin) || point.y > yMax + (yMax-yMin)) { drawing = false; continue; }
      const x = px(point.x), y = py(point.y);
      if (!drawing) { ctx.moveTo(x, y); drawing = true; } else ctx.lineTo(x, y);
    }
    ctx.stroke();
    if (xMin <= 0 && xMax >= 0) { ctx.strokeStyle = ink; ctx.globalAlpha = .45; ctx.beginPath(); ctx.moveTo(px(0), pad.top); ctx.lineTo(px(0), pad.top + plotHeight); ctx.stroke(); ctx.globalAlpha = 1; }
    if (yMin <= 0 && yMax >= 0) { ctx.strokeStyle = ink; ctx.globalAlpha = .45; ctx.beginPath(); ctx.moveTo(pad.left, py(0)); ctx.lineTo(pad.left + plotWidth, py(0)); ctx.stroke(); ctx.globalAlpha = 1; }
    status.textContent = `Plotted f(x) = ${expressionText} for x from ${formatNumber(xMin)} to ${formatNumber(xMax)}.`;
  }
  $("#plot-button").addEventListener("click", drawGraph);
  for (const selector of ["#graph-expression", "#graph-min", "#graph-max"]) $(selector).addEventListener("keydown", (event) => { if (event.key === "Enter") drawGraph(); });
  if ("ResizeObserver" in window) new ResizeObserver(() => drawGraph()).observe($(".graph-frame"));

  $("#solve-quadratic").addEventListener("click", () => {
    const a = Number($("#solve-a").value), b = Number($("#solve-b").value), c = Number($("#solve-c").value);
    if (![a, b, c].every(Number.isFinite)) { $("#solve-result").textContent = "Enter finite coefficients."; return; }
    if (a === 0) { $("#solve-result").textContent = b === 0 ? (c === 0 ? "Every x is a solution." : "No solution.") : `x = ${formatNumber(-c / b)}`; return; }
    const discriminant = b * b - 4 * a * c;
    if (discriminant < 0) {
      const real = -b / (2 * a), imaginary = Math.sqrt(-discriminant) / (2 * a);
      $("#solve-result").textContent = `x = ${formatNumber(real)} ± ${formatNumber(Math.abs(imaginary))}i`;
    } else {
      const root = Math.sqrt(discriminant), first = (-b - root) / (2 * a), second = (-b + root) / (2 * a);
      $("#solve-result").textContent = discriminant === 0 ? `x = ${formatNumber(first)}` : `x = ${formatNumber(first)}, x = ${formatNumber(second)}`;
    }
  });

  $("#find-roots").addEventListener("click", () => {
    const source = $("#root-expression").value.trim(), min = Number($("#root-min").value), max = Number($("#root-max").value), output = $("#root-result");
    if (!source || !Number.isFinite(min) || !Number.isFinite(max) || min >= max) { output.textContent = "Enter a function and increasing interval."; return; }
    const found = []; const steps = 800;
    try {
      let left = min, fLeft = evaluateExpression(source, left);
      for (let index = 1; index <= steps; index++) {
        const right = min + (max - min) * index / steps, fRight = evaluateExpression(source, right);
        if (fLeft === 0) found.push(left);
        else if (Number.isFinite(fLeft) && Number.isFinite(fRight) && fLeft * fRight < 0) {
          let lo = left, hi = right, flo = fLeft;
          for (let iteration = 0; iteration < 64; iteration++) {
            const mid = (lo + hi) / 2, fm = evaluateExpression(source, mid);
            if (Math.abs(fm) < 1e-12) { lo = hi = mid; break; }
            if (flo * fm <= 0) hi = mid; else { lo = mid; flo = fm; }
          }
          const root = (lo + hi) / 2;
          if (!found.some((value) => Math.abs(value - root) < 1e-5)) found.push(root);
        }
        left = right; fLeft = fRight;
      }
      output.textContent = found.length ? found.slice(0, 12).map((root) => `x ≈ ${formatNumber(root)}`).join(" · ") : "No sign-changing roots found in this interval.";
    } catch (error) { output.textContent = error.message || "Could not solve this function."; }
  });

  $("#differentiate").addEventListener("click", () => {
    const source = $("#calculus-expression").value.trim(), x = Number($("#derivative-x").value);
    if (!source || !Number.isFinite(x)) { $("#calculus-result").textContent = "Enter a function and x value."; return; }
    try {
      const h = 1e-5 * Math.max(1, Math.abs(x));
      const result = (evaluateExpression(source, x + h) - evaluateExpression(source, x - h)) / (2 * h);
      $("#calculus-result").textContent = `f′(${formatNumber(x)}) ≈ ${formatNumber(result)}`;
    } catch (error) { $("#calculus-result").textContent = error.message || "Could not estimate the derivative."; }
  });
  $("#integrate").addEventListener("click", () => {
    const source = $("#calculus-expression").value.trim(), a = Number($("#integral-a").value), b = Number($("#integral-b").value);
    if (!source || !Number.isFinite(a) || !Number.isFinite(b)) { $("#calculus-result").textContent = "Enter a function and finite bounds."; return; }
    if (a === b) { $("#calculus-result").textContent = "Integral = 0"; return; }
    const count = 1200, step = (b - a) / count;
    try {
      let sum = evaluateExpression(source, a) + evaluateExpression(source, b);
      for (let index = 1; index < count; index++) sum += (index % 2 ? 4 : 2) * evaluateExpression(source, a + step * index);
      $("#calculus-result").textContent = `∫ ≈ ${formatNumber(sum * step / 3)}`;
    } catch (error) { $("#calculus-result").textContent = error.message || "Could not estimate the integral."; }
  });

  $("#calculate-stats").addEventListener("click", () => {
    const raw = $("#stats-data").value.trim(), values = raw.split(/[\s,;]+/).filter(Boolean).map(Number), status = $("#stats-status"), container = $("#stats-results");
    container.replaceChildren();
    if (!raw || values.length > 5000 || !values.length || values.some((value) => !Number.isFinite(value))) { status.textContent = "Enter up to 5,000 finite numbers separated by commas, spaces, or new lines."; return; }
    const sorted = [...values].sort((a, b) => a - b), count = values.length, mean = values.reduce((sum, value) => sum + value, 0) / count;
    const percentile = (fraction) => { const position = (count - 1) * fraction, lower = Math.floor(position), upper = Math.ceil(position); return sorted[lower] + (sorted[upper] - sorted[lower]) * (position - lower); };
    const median = count % 2 ? sorted[(count - 1) / 2] : (sorted[count / 2 - 1] + sorted[count / 2]) / 2;
    const frequencies = new Map(); for (const value of values) frequencies.set(value, (frequencies.get(value) || 0) + 1);
    const maxFrequency = Math.max(...frequencies.values()), modes = maxFrequency > 1 ? [...frequencies].filter(([, frequency]) => frequency === maxFrequency).map(([value]) => formatNumber(value)).join(", ") : "No repeated mode";
    const mode = $("#stats-mode").value, denominator = mode === "sample" ? count - 1 : count;
    const variance = denominator > 0 ? values.reduce((sum, value) => sum + (value - mean) ** 2, 0) / denominator : NaN;
    const q1 = percentile(.25), q3 = percentile(.75);
    const metrics = [["Count", count], ["Mean", formatNumber(mean)], ["Median", formatNumber(median)], ["Mode", modes], ["Q1", formatNumber(q1)], ["Q3", formatNumber(q3)], ["Interquartile range", formatNumber(q3 - q1)], ["Minimum", formatNumber(sorted[0])], ["Maximum", formatNumber(sorted.at(-1))], ["Range", formatNumber(sorted.at(-1) - sorted[0])], [mode === "sample" ? "Sample variance" : "Population variance", Number.isFinite(variance) ? formatNumber(variance) : "Needs 2 values"], ["Std. deviation", Number.isFinite(variance) ? formatNumber(Math.sqrt(variance)) : "—"]];
    for (const [label, value] of metrics) { const card = document.createElement("div"); card.className = "stat-card"; card.append(textElement("span", "", label), textElement("strong", "", String(value))); container.append(card); }
    status.textContent = `Summarized ${count} number${count === 1 ? "" : "s"} as ${mode} data.`;
  });

  $("#calculate-trig").addEventListener("click", () => {
    const input = Number($("#trig-value").value), angle = $("#trig-angle").value, operation = $("#trig-operation").value;
    if (!Number.isFinite(input)) { $("#trig-result").textContent = "Enter a finite number."; return; }
    const radians = angle === "deg" ? input * Math.PI / 180 : input;
    const fromRadians = (value) => angle === "deg" ? value * 180 / Math.PI : value;
    const result = ({ sin: Math.sin(radians), cos: Math.cos(radians), tan: Math.tan(radians), csc: 1 / Math.sin(radians), sec: 1 / Math.cos(radians), cot: 1 / Math.tan(radians), asin: fromRadians(Math.asin(input)), acos: fromRadians(Math.acos(input)), atan: fromRadians(Math.atan(input)), sinh: Math.sinh(input), cosh: Math.cosh(input), tanh: Math.tanh(input) })[operation];
    try { $("#trig-result").textContent = formatNumber(result); }
    catch (error) { $("#trig-result").textContent = error.message || "That value is outside this function’s domain."; }
  });

  let formulas = storage.read("apex-mobile-formulas", []);
  if (!Array.isArray(formulas)) formulas = [];
  formulas = formulas.filter((item) => item && typeof item.name === "string" && typeof item.expression === "string").slice(0, 200);
  let selectedFormula = "";
  function renderFormulas() {
    const list = $("#formula-list"); list.replaceChildren();
    if (!formulas.length) { list.append(textElement("p", "empty-note", "No saved formulas yet.")); return; }
    for (const formula of formulas) {
      const item = document.createElement("button"); item.type = "button"; item.className = "formula-item"; item.setAttribute("aria-pressed", String(selectedFormula === formula.name));
      item.append(textElement("strong", "", `${formula.favorite ? "★ " : ""}${formula.name}`), textElement("span", "", formula.expression));
      item.addEventListener("click", () => { selectedFormula = formula.name; $("#formula-name").value = formula.name; $("#formula-expression").value = formula.expression; $("#formula-favorite").checked = Boolean(formula.favorite); renderFormulas(); });
      list.append(item);
    }
  }
  function saveFormulas() { storage.write("apex-mobile-formulas", formulas); renderFormulas(); }
  $("#save-formula").addEventListener("click", () => {
    const name = $("#formula-name").value.trim(), expressionText = $("#formula-expression").value.trim();
    if (!name || !expressionText) { notify("Add a name and a formula first."); return; }
    try { evaluateExpression(expressionText, Number($("#formula-x").value || 0)); }
    catch (error) { notify(error.message || "Check this formula before saving it."); return; }
    const previous = formulas.find((item) => item.name.toLowerCase() === name.toLowerCase());
    formulas = formulas.filter((item) => item.name.toLowerCase() !== name.toLowerCase());
    formulas.unshift({ name, expression: expressionText, favorite: $("#formula-favorite").checked || Boolean(previous?.favorite) });
    formulas = formulas.slice(0, 200); selectedFormula = name; saveFormulas(); notify("Formula saved on this device.");
  });
  $("#run-formula").addEventListener("click", () => {
    try { const value = evaluateExpression($("#formula-expression").value, Number($("#formula-x").value)); $("#formula-result").textContent = formatNumber(value); }
    catch (error) { $("#formula-result").textContent = error.message || "Check the formula and x value."; }
  });
  $("#delete-formula").addEventListener("click", () => {
    const name = selectedFormula || $("#formula-name").value.trim();
    if (!name || !formulas.some((item) => item.name === name)) { notify("Select a saved formula to delete."); return; }
    formulas = formulas.filter((item) => item.name !== name); selectedFormula = ""; saveFormulas(); notify("Formula removed from this device.");
  });
  function downloadJson(filename, data) {
    const link = document.createElement("a"), url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
    link.href = url; link.download = filename; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  $("#export-formulas").addEventListener("click", () => downloadJson("apex-formulas.json", { version: 1, formulas }));
  $("#import-formulas").addEventListener("click", () => $("#formula-file").click());
  $("#formula-file").addEventListener("change", async () => {
    const file = $("#formula-file").files?.[0]; if (!file) return;
    try {
      const data = JSON.parse(await file.text()), rows = Array.isArray(data) ? data : data.formulas;
      if (!Array.isArray(rows) || rows.length > 200) throw new Error("Choose a valid Apex formula file with up to 200 items.");
      const accepted = rows.filter((item) => item && typeof item.name === "string" && item.name.trim() && item.name.length <= 60 && typeof item.expression === "string" && item.expression.length <= 240)
        .map((item) => ({ name: item.name.trim(), expression: item.expression.trim(), favorite: Boolean(item.favorite) }));
      if (!accepted.length) throw new Error("No valid formulas were found in that file.");
      const byName = new Map(formulas.map((item) => [item.name.toLowerCase(), item]));
      for (const item of accepted) byName.set(item.name.toLowerCase(), item);
      formulas = [...byName.values()].slice(0, 200); saveFormulas(); notify(`Imported ${accepted.length} formula${accepted.length === 1 ? "" : "s"}.`);
    } catch (error) { notify(error.message || "That formula file couldn't be imported."); }
    $("#formula-file").value = "";
  });
  renderFormulas();

  $("#dictionary-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const word = $("#dictionary-word").value.trim();
    if (!word || /\s/.test(word)) { $("#dictionary-status").textContent = "Look up one word at a time."; return; }
    const status = $("#dictionary-status"); const results = $("#dictionary-results");
    status.textContent = `Looking up “${word}”…`;
    results.replaceChildren();
    try {
      const response = await fetch(`./api/dictionary?word=${encodeURIComponent(word)}`, { cache: "no-store" });
      const data = await response.json();
      if (!response.ok || !Array.isArray(data)) {
        const title = data?.title || data?.message || data?.error || "No definition found. Check the spelling or try another word.";
        status.textContent = title;
        return;
      }
      status.textContent = `Found “${word}” · Free Dictionary API`;
      for (const entry of data) renderWordEntry(entry, results);
      if (!results.childElementCount) status.textContent = "No definition details were returned for that word.";
    } catch {
      status.textContent = "Couldn't reach the dictionary. Check your internet connection and try again.";
    }
  });

  function textElement(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    element.textContent = text || "";
    return element;
  }
  function renderWordEntry(entry, container) {
    const card = document.createElement("article"); card.className = "word-entry";
    const head = document.createElement("div"); head.className = "word-head";
    const left = document.createElement("div");
    left.append(textElement("h2", "", entry.word || "Word"));
    const phonetic = entry.phonetic || entry.phonetics?.find((item) => item.text)?.text;
    if (phonetic) left.append(textElement("div", "word-phonetic", phonetic));
    head.append(left);
    const audioUrl = entry.phonetics?.find((item) => item.audio)?.audio;
    if (audioUrl && /^https?:\/\//i.test(audioUrl)) {
      const audio = document.createElement("audio"); audio.className = "audio-player"; audio.controls = true; audio.preload = "none"; audio.src = audioUrl; audio.setAttribute("aria-label", `Pronounce ${entry.word || "word"}`); head.append(audio);
    }
    card.append(head);
    for (const meaning of entry.meanings || []) {
      const section = document.createElement("section"); section.className = "meaning";
      section.append(textElement("h3", "", meaning.partOfSpeech || "Meaning"));
      for (const definition of (meaning.definitions || []).slice(0, 8)) {
        const block = document.createElement("div"); block.className = "definition";
        block.append(document.createTextNode(definition.definition || ""));
        if (definition.example) block.append(textElement("span", "example", `Example: “${definition.example}”`));
        if (definition.synonyms?.length) block.append(textElement("div", "word-list", `Synonyms: ${definition.synonyms.slice(0, 6).join(", ")}`));
        if (definition.antonyms?.length) block.append(textElement("div", "word-list", `Antonyms: ${definition.antonyms.slice(0, 6).join(", ")}`));
        section.append(block);
      }
      card.append(section);
    }
    if (entry.origin) card.append(textElement("p", "word-list", `Origin: ${entry.origin}`));
    container.append(card);
  }

  $("#search-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const query = $("#search-query").value.trim();
    if (!query) return;
    const status = $("#search-status"); const results = $("#search-results");
    status.textContent = "Searching DuckDuckGo…";
    results.replaceChildren();
    try {
      const response = await fetch(`./api/search?q=${encodeURIComponent(query)}`, { cache: "no-store" });
      const data = await response.json();
      if (!response.ok || data.error) { status.textContent = data.error || "Search failed. Try again."; return; }
      if (!data.results?.length) { status.textContent = "No readable results came back. Try a shorter search phrase."; return; }
      status.textContent = `Showing ${data.results.length} results for “${query}”. Results stay here until you choose a title.`;
      for (const result of data.results) {
        const card = document.createElement("article"); card.className = "result-card";
        const link = document.createElement("a"); link.href = result.url; link.target = "_blank"; link.rel = "noopener noreferrer"; link.textContent = result.title;
        card.append(link, textElement("div", "result-host", result.host), textElement("p", "", result.snippet));
        results.append(card);
      }
    } catch {
      status.textContent = "Couldn't reach DuckDuckGo. Check your internet connection and try again.";
    }
  });

  const installButton = $("#install-button");
  const installDialog = $("#install-dialog");
  const closeInstall = () => installDialog.close();
  $("#close-install").addEventListener("click", closeInstall);
  installDialog.addEventListener("click", (event) => { if (event.target === installDialog) closeInstall(); });
  let installPrompt = null;
  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault(); installPrompt = event;
  });
  installButton.addEventListener("click", async () => {
    if (installPrompt) {
      installPrompt.prompt();
      await installPrompt.userChoice;
      installPrompt = null;
    } else if (typeof installDialog.showModal === "function") installDialog.showModal();
    else notify("Open your browser menu and choose Add to Home Screen.");
  });
  if (window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone) installButton.hidden = true;

  renderCalc(); renderHistory(); renderRecent(); fillUnits(); updateProgrammer(); updateBitwise();
  if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) {
    const banner = $("#update-banner"), copy = $("#update-copy");
    const updateNow = $("#update-now"), dismissUpdate = $("#update-dismiss");
    let updateRegistration = null, reloadAfterUpdate = false, bannerTimer;
    function showUpdate(message, canUpdate = false, canDismiss = false) {
      copy.textContent = message; updateNow.hidden = !canUpdate; dismissUpdate.hidden = !canDismiss;
      banner.hidden = false; banner.classList.toggle("update-ready", canUpdate);
    }
    function hideUpdate() { banner.hidden = true; }
    dismissUpdate.addEventListener("click", hideUpdate);
    navigator.serviceWorker.addEventListener("controllerchange", () => {
      if (!reloadAfterUpdate) return;
      reloadAfterUpdate = false; showUpdate("Apex updated — reopening the latest version…"); location.reload();
    });
    updateNow.addEventListener("click", () => {
      if (!updateRegistration?.waiting) return;
      reloadAfterUpdate = true; showUpdate("Updating Apex… please keep this page open.");
      updateRegistration.waiting.postMessage({ type: "SKIP_WAITING" });
    });
    showUpdate("Checking for Apex updates…");
    navigator.serviceWorker.register("./service-worker.js").then((registration) => {
      updateRegistration = registration;
      const waitingWorker = () => {
        if (registration.waiting && navigator.serviceWorker.controller) {
          showUpdate("A new Apex update is ready to install.", true, true); return true;
        }
        return false;
      };
      if (waitingWorker()) return;
      registration.addEventListener("updatefound", () => {
        const worker = registration.installing; if (!worker) return;
        if (navigator.serviceWorker.controller) showUpdate("Downloading an Apex update…");
        worker.addEventListener("statechange", () => {
          if (worker.state === "installed" && navigator.serviceWorker.controller)
            showUpdate("A new Apex update is ready to install.", true, true);
        });
      });
      registration.update().catch(() => {});
      clearTimeout(bannerTimer);
      bannerTimer = setTimeout(() => {
        if (!registration.waiting && !registration.installing) {
          showUpdate("Apex is up to date."); bannerTimer = setTimeout(hideUpdate, 1700);
        }
      }, 900);
    }).catch(() => {
      showUpdate("Apex update checks need an HTTPS connection."); bannerTimer = setTimeout(hideUpdate, 3000);
    });
  }
})();
