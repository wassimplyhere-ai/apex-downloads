(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const toast = $("#toast");
  let toastTimer;

  function notify(message) {
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2400);
  }

  function formatNumber(value) {
    if (!Number.isFinite(value)) throw new Error("That result is outside the supported range.");
    if (Object.is(value, -0)) value = 0;
    return Number(value.toPrecision(12)).toString();
  }

  function evaluateExpression(source) {
    const normalized = source.replaceAll("×", "*").replaceAll("÷", "/").replaceAll("−", "-").trim();
    const tokens = normalized.match(/(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?|[()+\-*/]/gi) || [];
    if (!normalized || tokens.join("") !== normalized.replace(/\s/g, "")) throw new Error("Check the expression and try again.");
    let index = 0;
    const peek = () => tokens[index];
    const take = () => tokens[index++];
    function primary() {
      if (peek() === "(") {
        take();
        const value = sum();
        if (take() !== ")") throw new Error("Add a closing parenthesis.");
        return value;
      }
      const token = take();
      if (token === undefined || !/^(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(token)) throw new Error("Check the expression and try again.");
      return Number(token);
    }
    function unary() {
      if (peek() === "+") { take(); return unary(); }
      if (peek() === "-") { take(); return -unary(); }
      return primary();
    }
    function product() {
      let value = unary();
      while (peek() === "*" || peek() === "/") {
        const operator = take();
        const right = unary();
        value = operator === "*" ? value * right : value / right;
      }
      return value;
    }
    function sum() {
      let value = product();
      while (peek() === "+" || peek() === "-") {
        const operator = take();
        const right = product();
        value = operator === "+" ? value + right : value - right;
      }
      return value;
    }
    const result = sum();
    if (index !== tokens.length) throw new Error("Check the expression and try again.");
    if (!Number.isFinite(result)) throw new Error("That result is outside the supported range.");
    return result;
  }

  const storage = {
    read(key, fallback) {
      try {
        const value = JSON.parse(localStorage.getItem(key) || "null");
        return value ?? fallback;
      } catch { return fallback; }
    },
    write(key, value) {
      try { localStorage.setItem(key, JSON.stringify(value)); }
      catch { notify("This browser couldn't save local history."); }
    }
  };

  const themes = {
    soft: { ink: "#463452", muted: "#786889", plum: "#8a66a1", rose: "#f2a9c8", pink: "#f9d9e7", lilac: "#e6daf4", lavender: "#f5effa", blue: "#c5eaf4", mint: "#d9f0e2", white: "#fffdfd", line: "#e8deed" },
    ocean: { ink: "#183e50", muted: "#527989", plum: "#167c8c", rose: "#75cad1", pink: "#d1f0ee", lilac: "#c6e9ec", lavender: "#e9f7f6", blue: "#a8dfee", mint: "#bde9d9", white: "#faffff", line: "#b9dfe1" },
    neon: { ink: "#f4f0ff", muted: "#aaa3c8", plum: "#c26dff", rose: "#ff4fa3", pink: "#332344", lilac: "#302451", lavender: "#111322", blue: "#2b405a", mint: "#224541", white: "#1b1d30", line: "#40395c" },
    terminal: { ink: "#a7f5b5", muted: "#62b97a", plum: "#55ee79", rose: "#226f3b", pink: "#163d27", lilac: "#17472d", lavender: "#07170e", blue: "#164a47", mint: "#17472d", white: "#0b2113", line: "#28643b" },
    paper: { ink: "#483624", muted: "#887458", plum: "#986b3e", rose: "#d6ad7c", pink: "#f3e3ca", lilac: "#e9d8b9", lavender: "#f5eddd", blue: "#d4e0d8", mint: "#dce5cb", white: "#fffaf0", line: "#ddcfb6" },
    arcade: { ink: "#27154f", muted: "#66549a", plum: "#713aff", rose: "#ff56ac", pink: "#ffd0f0", lilac: "#d9c7ff", lavender: "#f2eaff", blue: "#79e8ff", mint: "#a4f7d2", white: "#fffaff", line: "#bba5ed" }
  };
  let preferences = storage.read("apex-mobile-preferences", { preset: "soft", style: "soft", custom: null, sounds: true, soundStyle: "soft" });
  if (!preferences || typeof preferences !== "object") preferences = { preset: "soft", style: "soft", custom: null, sounds: true, soundStyle: "soft" };
  const legacyPresets = { lavender: "soft", sky: "ocean", forest: "paper", midnight: "neon" };
  preferences.preset = legacyPresets[preferences.preset] || preferences.preset || "soft";
  if (!themes[preferences.style]) preferences.style = preferences.preset === "custom" ? "soft" : preferences.preset;
  if (typeof preferences.sounds !== "boolean") preferences.sounds = true;
  if (!["soft", "mechanical", "bubble", "arcade"].includes(preferences.soundStyle)) preferences.soundStyle = "soft";
  const rootStyle = document.documentElement.style;

  function parseHex(value, fallback) { return /^#[\da-f]{6}$/i.test(value || "") ? value : fallback; }
  function mixHex(first, second, firstWeight) {
    const a = first.match(/[\da-f]{2}/gi).map((part) => Number.parseInt(part, 16));
    const b = second.match(/[\da-f]{2}/gi).map((part) => Number.parseInt(part, 16));
    return `#${a.map((value, index) => Math.round(value * firstWeight + b[index] * (1 - firstWeight)).toString(16).padStart(2, "0")).join("")}`;
  }
  function customPalette(colors) {
    const background = parseHex(colors.background, themes.soft.lavender);
    const card = parseHex(colors.card, themes.soft.white);
    const text = parseHex(colors.text, themes.soft.ink);
    const accent = parseHex(colors.accent, themes.soft.plum);
    const cool = parseHex(colors.cool, themes.soft.blue);
    const rose = mixHex(accent, card, .55);
    return {
      ink: text,
      muted: mixHex(text, background, .58),
      plum: accent,
      rose,
      pink: mixHex(rose, card, .45),
      lilac: mixHex(accent, background, .18),
      lavender: background,
      blue: cool,
      mint: mixHex(cool, card, .38),
      white: card,
      line: mixHex(accent, background, .2)
    };
  }
  function activeStyle() {
    return preferences.preset === "custom" ? (themes[preferences.style] ? preferences.style : "soft") : preferences.preset;
  }
  function applyPalette(palette) {
    for (const [name, value] of Object.entries(palette)) rootStyle.setProperty(`--${name}`, value);
    const style = activeStyle();
    document.documentElement.dataset.theme = style;
    document.querySelector('meta[name="theme-color"]').content = palette.lavender;
    $("#style-name").textContent = preferences.preset === "custom" ? `Custom · ${style[0].toUpperCase()}${style.slice(1)}` : ({ soft: "Cozy Pink", ocean: "Ocean Glass", neon: "Midnight Neon", terminal: "Retro Terminal", paper: "Warm Paper", arcade: "Arcade" })[style];
  }
  function paletteForPreferences() {
    return preferences.preset === "custom" && preferences.custom
      ? customPalette(preferences.custom)
      : themes[preferences.preset] || themes.soft;
  }
  function savePreferences() {
    storage.write("apex-mobile-preferences", preferences);
    applyPalette(paletteForPreferences());
    $("#click-sounds").checked = preferences.sounds;
    $("#click-sound-style").value = preferences.soundStyle;
  }
  applyPalette(paletteForPreferences());

  let audioContext = null;
  function playClickSound() {
    if (!preferences.sounds) return;
    try {
      const AudioContextType = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextType) return;
      audioContext ||= new AudioContextType();
      if (audioContext.state === "suspended") audioContext.resume();
      const now = audioContext.currentTime;
      const oscillator = audioContext.createOscillator();
      const volume = audioContext.createGain();
      const soundStyle = preferences.soundStyle || "soft";
      const settings = {
        soft: { type: "sine", start: 1080, end: 560, duration: .04, gain: .032 },
        mechanical: { type: "square", start: 430, end: 260, duration: .022, gain: .018 },
        bubble: { type: "sine", start: 520, end: 1320, duration: .075, gain: .035 },
        arcade: { type: "triangle", start: 760, end: 1120, duration: .055, gain: .028 }
      }[soundStyle] || { type: "sine", start: 1080, end: 560, duration: .04, gain: .032 };
      oscillator.type = settings.type;
      oscillator.frequency.setValueAtTime(settings.start, now);
      oscillator.frequency.exponentialRampToValueAtTime(settings.end, now + settings.duration * .75);
      volume.gain.setValueAtTime(settings.gain, now);
      volume.gain.exponentialRampToValueAtTime(.001, now + settings.duration);
      oscillator.connect(volume); volume.connect(audioContext.destination);
      oscillator.start(now); oscillator.stop(now + settings.duration + .005);
    } catch { /* Audio is optional; the controls remain usable without it. */ }
  }
  document.addEventListener("click", (event) => {
    if (event.target.closest("button:not(:disabled)")) playClickSound();
  });

  const themeDialog = $("#theme-dialog");
  const themePreset = $("#theme-preset");
  const customColors = $("#custom-colors");
  const colorInputs = {
    background: $("#custom-background"), card: $("#custom-card"), text: $("#custom-text"),
    accent: $("#custom-accent"), cool: $("#custom-cool")
  };
  function fillCustomInputs(colors) {
    colorInputs.background.value = colors.background;
    colorInputs.card.value = colors.card;
    colorInputs.text.value = colors.text;
    colorInputs.accent.value = colors.accent;
    colorInputs.cool.value = colors.cool;
  }
  function setInputsFromPalette(palette) {
    fillCustomInputs({ background: palette.lavender, card: palette.white, text: palette.ink, accent: palette.plum, cool: palette.blue });
  }
  $("#theme-button").addEventListener("click", () => {
    themePreset.value = preferences.preset;
    const currentPalette = paletteForPreferences();
    const custom = preferences.custom || { background: currentPalette.lavender, card: currentPalette.white, text: currentPalette.ink, accent: currentPalette.plum, cool: currentPalette.blue };
    fillCustomInputs(custom);
    $("#click-sounds").checked = preferences.sounds;
    $("#click-sound-style").value = preferences.soundStyle;
    $("#custom-style").value = preferences.style || "soft";
    customColors.hidden = themePreset.value !== "custom";
    $("#custom-style-row").hidden = themePreset.value !== "custom";
    $("#custom-style").hidden = themePreset.value !== "custom";
    if (typeof themeDialog.showModal === "function") themeDialog.showModal();
  });
  themePreset.addEventListener("change", () => {
    customColors.hidden = themePreset.value !== "custom";
    $("#custom-style-row").hidden = themePreset.value !== "custom";
    $("#custom-style").hidden = themePreset.value !== "custom";
    if (themePreset.value !== "custom") setInputsFromPalette(themes[themePreset.value] || themes.soft);
  });
  $("#close-theme").addEventListener("click", () => themeDialog.close());
  $("#cancel-theme").addEventListener("click", () => themeDialog.close());
  $("#theme-form").addEventListener("submit", (event) => {
    event.preventDefault();
    preferences.preset = themePreset.value;
    preferences.style = themePreset.value === "custom" ? $("#custom-style").value : themePreset.value;
    preferences.soundStyle = $("#click-sound-style").value;
    preferences.sounds = $("#click-sounds").checked;
    if (preferences.preset === "custom") {
      preferences.custom = Object.fromEntries(Object.entries(colorInputs).map(([key, input]) => [key, input.value]));
    }
    savePreferences();
    themeDialog.close();
    notify("Apex preferences saved on this device.");
  });

  let history = storage.read("apex-mobile-history", []);
  if (!Array.isArray(history)) history = [];
  history = history.filter((row) => row && typeof row.expression === "string" && typeof row.answer === "string").slice(0, 30);
  let expression = "0";
  let memory = 0;
  let replaceOnDigit = true;

  const display = $("#calc-display");
  const caption = $("#calc-caption");

  function renderCalc() {
    display.textContent = expression;
    $("#memory-indicator").textContent = memory === 0 ? "Memory empty" : "Memory saved";
  }

  function addHistory(source, answer) {
    history.unshift({ expression: source, answer, time: Date.now() });
    history = history.slice(0, 30);
    storage.write("apex-mobile-history", history);
    renderHistory();
    renderRecent();
  }

  function calculate() {
    const source = expression;
    try {
      const result = formatNumber(evaluateExpression(source));
      caption.textContent = source;
      expression = result;
      replaceOnDigit = true;
      renderCalc();
      addHistory(source, result);
    } catch (error) {
      notify(error.message || "Check the expression and try again.");
    }
  }

  function appendValue(value) {
    const isDigit = /\d|\./.test(value);
    if (replaceOnDigit && isDigit) {
      expression = value === "." ? "0." : value;
      caption.textContent = "Apex calculator";
      replaceOnDigit = false;
      renderCalc();
      return;
    }
    const isOperator = ["+", "−", "×", "÷"].includes(value);
    if (isOperator && /[+−×÷]$/.test(expression)) expression = expression.slice(0, -1);
    if (value === ".") {
      const tail = expression.split(/[+−×÷]/).at(-1) || "";
      if (tail.includes(".")) return;
      if (!tail) expression += "0";
    }
    if (expression === "0" && value !== "." && !isOperator) expression = "";
    expression += value;
    replaceOnDigit = false;
    renderCalc();
  }

  function calcAction(action) {
    if (action === "clear") {
      expression = "0"; caption.textContent = "Apex calculator"; replaceOnDigit = true; renderCalc(); return;
    }
    if (action === "backspace") {
      expression = expression.length > 1 ? expression.slice(0, -1) : "0"; replaceOnDigit = false; renderCalc(); return;
    }
    if (action === "equals") return calculate();
    if (action === "sign" || action === "percent" || action === "square" || action === "sqrt" || action === "reciprocal" || action === "memory-add") {
      try {
        const current = evaluateExpression(expression);
        let next = current;
        if (action === "sign") next = -current;
        if (action === "percent") next = current / 100;
        if (action === "square") next = current * current;
        if (action === "sqrt") next = Math.sqrt(current);
        if (action === "reciprocal") next = 1 / current;
        if (action === "memory-add") { memory += current; notify("Added to memory."); renderCalc(); return; }
        caption.textContent = expression;
        expression = formatNumber(next);
        replaceOnDigit = true;
        renderCalc();
      } catch (error) { notify(error.message || "That operation isn't available for this value."); }
      return;
    }
    if (action === "memory-clear") { memory = 0; renderCalc(); notify("Memory cleared."); return; }
    if (action === "memory-recall") { expression = formatNumber(memory); replaceOnDigit = true; renderCalc(); return; }
  }

  $("#keypad").addEventListener("click", (event) => {
    const button = event.target.closest("button");
    if (!button) return;
    if (button.dataset.action) calcAction(button.dataset.action);
    else if (button.dataset.value) appendValue(button.dataset.value);
  });

  document.addEventListener("keydown", (event) => {
    const activePanel = $(".panel.active");
    if (activePanel?.id !== "panel-standard" || /^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement?.tagName || "")) return;
    if (document.activeElement instanceof HTMLButtonElement && (event.key === "Enter" || event.key === " ")) return;
    let handled = true;
    if (/^[0-9.]$/.test(event.key)) appendValue(event.key);
    else if (event.key === "Enter" || event.key === "=") calculate();
    else if (event.key === "Backspace") calcAction("backspace");
    else if (event.key === "Escape") calcAction("clear");
    else if (event.key === "+") appendValue("+");
    else if (event.key === "-") appendValue("−");
    else if (event.key === "*") appendValue("×");
    else if (event.key === "/") appendValue("÷");
    else handled = false;
    if (handled) { playClickSound(); event.preventDefault(); }
  });

  function renderHistory() {
    const container = $("#history-list");
    container.replaceChildren();
    if (!history.length) {
      container.innerHTML = '<div class="empty-state"><span aria-hidden="true">♡</span><h2>No calculations yet.</h2><p>Try the Standard panel and your recent answers will appear here.</p></div>';
      return;
    }
    for (const row of history) {
      const item = document.createElement("button");
      item.type = "button";
      item.className = "history-item";
      item.innerHTML = '<span class="history-expression"></span><strong class="history-answer"></strong>';
      item.querySelector(".history-expression").textContent = row.expression;
      item.querySelector(".history-answer").textContent = row.answer;
      item.addEventListener("click", () => { expression = row.answer; caption.textContent = row.expression; replaceOnDigit = true; renderCalc(); showPanel("standard"); });
      container.append(item);
    }
  }

  function renderRecent() {
    const container = $("#recent-mini");
    container.replaceChildren();
    if (!history.length) { const note = document.createElement("p"); note.className = "empty-note"; note.textContent = "Your recent answers will show up here."; container.append(note); return; }
    for (const row of history.slice(0, 3)) {
      const item = document.createElement("div");
      item.className = "mini-entry";
      const expr = document.createElement("span"); expr.textContent = row.expression;
      const answer = document.createElement("strong"); answer.textContent = row.answer;
      item.append(expr, answer); container.append(item);
    }
  }

  $("#clear-history").addEventListener("click", () => {
    history = [];
    storage.write("apex-mobile-history", history);
    renderHistory(); renderRecent(); notify("Local calculation history cleared.");
  });

  const tabButtons = $$(".mode-tab");
  const panels = $$(".panel");
  function showPanel(name) {
    for (const button of tabButtons) {
      const selected = button.dataset.panel === name;
      button.classList.toggle("active", selected);
      button.setAttribute("aria-selected", String(selected));
      button.tabIndex = selected ? 0 : -1;
      if (selected && window.matchMedia("(max-width: 760px)").matches) button.scrollIntoView({ block: "nearest", inline: "center", behavior: "smooth" });
    }
    for (const panel of panels) {
      const selected = panel.id === `panel-${name}`;
      panel.hidden = !selected;
      panel.classList.toggle("active", selected);
    }
  }
  for (const button of tabButtons) button.addEventListener("click", () => showPanel(button.dataset.panel));
  $$('[data-go="history"]').forEach((button) => button.addEventListener("click", () => showPanel("history")));
  for (const button of tabButtons) {
    button.addEventListener("keydown", (event) => {
      if (!["ArrowRight", "ArrowLeft", "Home", "End"].includes(event.key)) return;
      event.preventDefault();
      const current = tabButtons.indexOf(button);
      const next = event.key === "Home" ? 0 : event.key === "End" ? tabButtons.length - 1 : (current + (event.key === "ArrowRight" ? 1 : -1) + tabButtons.length) % tabButtons.length;
      tabButtons[next].focus();
      showPanel(tabButtons[next].dataset.panel);
    });
  }

  const sciValue = $("#sci-value");
  const sciAngle = $("#angle-mode");
  const sciResult = $("#sci-result");
  $("#sci-grid").addEventListener("click", (event) => {
    const button = event.target.closest("[data-sci]");
    if (!button) return;
    const operation = button.dataset.sci;
    const input = Number(sciValue.value);
    const radians = sciAngle.value === "deg" ? input * Math.PI / 180 : input;
    const angleOut = (value) => sciAngle.value === "deg" ? value * 180 / Math.PI : value;
    let result;
    if (operation === "pi") result = Math.PI;
    else if (operation === "e") result = Math.E;
    else if (operation === "sin") result = Math.sin(radians);
    else if (operation === "cos") result = Math.cos(radians);
    else if (operation === "tan") result = Math.tan(radians);
    else if (operation === "asin") result = angleOut(Math.asin(input));
    else if (operation === "acos") result = angleOut(Math.acos(input));
    else if (operation === "atan") result = angleOut(Math.atan(input));
    else if (operation === "sqrt") result = Math.sqrt(input);
    else if (operation === "square") result = input * input;
    else if (operation === "log") result = Math.log10(input);
    else if (operation === "ln") result = Math.log(input);
    else if (operation === "reciprocal") result = 1 / input;
    else if (operation === "factorial") {
      if (!Number.isInteger(input) || input < 0 || input > 170) { notify("Factorial needs a whole number from 0 to 170."); return; }
      result = 1; for (let n = 2; n <= input; n++) result *= n;
    }
    try { sciResult.textContent = formatNumber(result); }
    catch (error) { sciResult.textContent = "—"; notify(error.message || "That result is not defined."); }
  });

  const programmerValue = $("#programmer-value");
  const programmerBase = $("#programmer-base");
  function parseInteger(text, base) {
    let source = text.trim().replaceAll("_", "");
    if (!source) throw new Error("Enter an integer value.");
    let negative = false;
    if (source.startsWith("-") || source.startsWith("+")) { negative = source[0] === "-"; source = source.slice(1); }
    if (base === 16 && /^0x/i.test(source)) source = source.slice(2);
    if (base === 2 && /^0b/i.test(source)) source = source.slice(2);
    if (base === 8 && /^0o/i.test(source)) source = source.slice(2);
    const patterns = { 2: /^[01]+$/, 8: /^[0-7]+$/, 10: /^\d+$/, 16: /^[\da-f]+$/i };
    if (!patterns[base].test(source)) throw new Error(`That isn't a valid base-${base} integer.`);
    const prefix = base === 16 ? "0x" : base === 8 ? "0o" : base === 2 ? "0b" : "";
    const value = BigInt(prefix + source);
    const signed = negative ? -value : value;
    if (signed < -(1n << 63n) || signed > (1n << 64n) - 1n) throw new Error("Use an integer between −2⁶³ and 2⁶⁴−1.");
    return signed;
  }
  function updateProgrammer() {
    try {
      const value = parseInteger(programmerValue.value, Number(programmerBase.value));
      $("#base-bin").textContent = value.toString(2);
      $("#base-oct").textContent = value.toString(8);
      $("#base-dec").textContent = value.toString(10);
      $("#base-hex").textContent = value.toString(16).toUpperCase();
    } catch (error) {
      for (const id of ["#base-bin", "#base-oct", "#base-dec", "#base-hex"]) $(id).textContent = "—";
      if (programmerValue.value.trim()) $("#base-dec").textContent = error.message;
    }
    updateBitwise();
  }
  programmerValue.addEventListener("input", updateProgrammer);
  programmerBase.addEventListener("change", updateProgrammer);
  function updateBitwise() {
    try {
      const left = BigInt($("#bitwise-a").value.trim());
      const right = BigInt($("#bitwise-b").value.trim());
      const operation = $("#bitwise-op").value;
      let result;
      if (operation === "and") result = left & right;
      else if (operation === "or") result = left | right;
      else if (operation === "xor") result = left ^ right;
      else if (operation === "shl") result = left << (right < 0n ? 0n : right > 63n ? 63n : right);
      else result = left >> (right < 0n ? 0n : right > 63n ? 63n : right);
      $("#bitwise-result").textContent = result.toString();
    } catch { $("#bitwise-result").textContent = "Enter integers"; }
  }
  $("#bitwise-a").addEventListener("input", updateBitwise);
  $("#bitwise-b").addEventListener("input", updateBitwise);
  $("#bitwise-op").addEventListener("change", updateBitwise);

  const unitSets = {
    Length: { m: 1, km: 1000, cm: .01, mm: .001, mile: 1609.344, ft: .3048, in: .0254 },
    Mass: { kg: 1, g: .001, lb: .45359237, oz: .028349523125 },
    Temperature: { "°C": 1, "°F": 1, K: 1 }
  };
  const categorySelect = $("#convert-category");
  const fromSelect = $("#convert-from");
  const toSelect = $("#convert-to");
  function fillUnits() {
    const units = Object.keys(unitSets[categorySelect.value]);
    const oldFrom = fromSelect.value; const oldTo = toSelect.value;
    fromSelect.replaceChildren(); toSelect.replaceChildren();
    for (const unit of units) {
      fromSelect.add(new Option(unit, unit)); toSelect.add(new Option(unit, unit));
    }
    fromSelect.value = units.includes(oldFrom) ? oldFrom : units[0];
    toSelect.value = units.includes(oldTo) ? oldTo : units[Math.min(1, units.length - 1)];
    updateConversion();
  }
  function convertTemperature(value, from, to) {
    const celsius = from === "°C" ? value : from === "°F" ? (value - 32) * 5 / 9 : value - 273.15;
    return to === "°C" ? celsius : to === "°F" ? celsius * 9 / 5 + 32 : celsius + 273.15;
  }
  function updateConversion() {
    const value = Number($("#convert-value").value);
    if (!Number.isFinite(value)) { $("#convert-result").textContent = "Enter a number"; return; }
    const from = fromSelect.value; const to = toSelect.value;
    const result = categorySelect.value === "Temperature" ? convertTemperature(value, from, to) : value * unitSets[categorySelect.value][from] / unitSets[categorySelect.value][to];
    try { $("#convert-result").textContent = `${formatNumber(result)} ${to}`; }
    catch { $("#convert-result").textContent = "—"; }
  }
  categorySelect.addEventListener("change", fillUnits);
  fromSelect.addEventListener("change", updateConversion);
  toSelect.addEventListener("change", updateConversion);
  $("#convert-value").addEventListener("input", updateConversion);

  $("#dictionary-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const word = $("#dictionary-word").value.trim();
    if (!word || /\s/.test(word)) { $("#dictionary-status").textContent = "Look up one word at a time."; return; }
    const status = $("#dictionary-status"); const results = $("#dictionary-results");
    status.textContent = `Looking up “${word}”…`;
    results.replaceChildren();
    try {
      const response = await fetch(`./api/dictionary?word=${encodeURIComponent(word)}`, { cache: "no-store" });
      const data = await response.json();
      if (!response.ok || !Array.isArray(data)) {
        const title = data?.title || data?.message || data?.error || "No definition found. Check the spelling or try another word.";
        status.textContent = title;
        return;
      }
      status.textContent = `Found “${word}” · Free Dictionary API`;
      for (const entry of data) renderWordEntry(entry, results);
      if (!results.childElementCount) status.textContent = "No definition details were returned for that word.";
    } catch {
      status.textContent = "Couldn't reach the dictionary. Check your internet connection and try again.";
    }
  });

  function textElement(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    element.textContent = text || "";
    return element;
  }
  function renderWordEntry(entry, container) {
    const card = document.createElement("article"); card.className = "word-entry";
    const head = document.createElement("div"); head.className = "word-head";
    const left = document.createElement("div");
    left.append(textElement("h2", "", entry.word || "Word"));
    const phonetic = entry.phonetic || entry.phonetics?.find((item) => item.text)?.text;
    if (phonetic) left.append(textElement("div", "word-phonetic", phonetic));
    head.append(left);
    const audioUrl = entry.phonetics?.find((item) => item.audio)?.audio;
    if (audioUrl && /^https?:\/\//i.test(audioUrl)) {
      const audio = document.createElement("audio"); audio.className = "audio-player"; audio.controls = true; audio.preload = "none"; audio.src = audioUrl; audio.setAttribute("aria-label", `Pronounce ${entry.word || "word"}`); head.append(audio);
    }
    card.append(head);
    for (const meaning of entry.meanings || []) {
      const section = document.createElement("section"); section.className = "meaning";
      section.append(textElement("h3", "", meaning.partOfSpeech || "Meaning"));
      for (const definition of (meaning.definitions || []).slice(0, 8)) {
        const block = document.createElement("div"); block.className = "definition";
        block.append(document.createTextNode(definition.definition || ""));
        if (definition.example) block.append(textElement("span", "example", `Example: “${definition.example}”`));
        if (definition.synonyms?.length) block.append(textElement("div", "word-list", `Synonyms: ${definition.synonyms.slice(0, 6).join(", ")}`));
        if (definition.antonyms?.length) block.append(textElement("div", "word-list", `Antonyms: ${definition.antonyms.slice(0, 6).join(", ")}`));
        section.append(block);
      }
      card.append(section);
    }
    if (entry.origin) card.append(textElement("p", "word-list", `Origin: ${entry.origin}`));
    container.append(card);
  }

  $("#search-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const query = $("#search-query").value.trim();
    if (!query) return;
    const status = $("#search-status"); const results = $("#search-results");
    status.textContent = "Searching DuckDuckGo…";
    results.replaceChildren();
    try {
      const response = await fetch(`./api/search?q=${encodeURIComponent(query)}`, { cache: "no-store" });
      const data = await response.json();
      if (!response.ok || data.error) { status.textContent = data.error || "Search failed. Try again."; return; }
      if (!data.results?.length) { status.textContent = "No readable results came back. Try a shorter search phrase."; return; }
      status.textContent = `Showing ${data.results.length} results for “${query}”. Results stay here until you choose a title.`;
      for (const result of data.results) {
        const card = document.createElement("article"); card.className = "result-card";
        const link = document.createElement("a"); link.href = result.url; link.target = "_blank"; link.rel = "noopener noreferrer"; link.textContent = result.title;
        card.append(link, textElement("div", "result-host", result.host), textElement("p", "", result.snippet));
        results.append(card);
      }
    } catch {
      status.textContent = "Couldn't reach DuckDuckGo. Check your internet connection and try again.";
    }
  });

  const installButton = $("#install-button");
  const installDialog = $("#install-dialog");
  const closeInstall = () => installDialog.close();
  $("#close-install").addEventListener("click", closeInstall);
  installDialog.addEventListener("click", (event) => { if (event.target === installDialog) closeInstall(); });
  let installPrompt = null;
  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault(); installPrompt = event;
  });
  installButton.addEventListener("click", async () => {
    if (installPrompt) {
      installPrompt.prompt();
      await installPrompt.userChoice;
      installPrompt = null;
    } else if (typeof installDialog.showModal === "function") installDialog.showModal();
    else notify("Open your browser menu and choose Add to Home Screen.");
  });
  if (window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone) installButton.hidden = true;

  renderCalc(); renderHistory(); renderRecent(); fillUnits(); updateProgrammer(); updateBitwise();
  if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) {
    const banner = $("#update-banner"), copy = $("#update-copy");
    const updateNow = $("#update-now"), dismissUpdate = $("#update-dismiss");
    let updateRegistration = null, reloadAfterUpdate = false, bannerTimer;
    function showUpdate(message, canUpdate = false, canDismiss = false) {
      copy.textContent = message; updateNow.hidden = !canUpdate; dismissUpdate.hidden = !canDismiss;
      banner.hidden = false; banner.classList.toggle("update-ready", canUpdate);
    }
    function hideUpdate() { banner.hidden = true; }
    dismissUpdate.addEventListener("click", hideUpdate);
    navigator.serviceWorker.addEventListener("controllerchange", () => {
      if (!reloadAfterUpdate) return;
      reloadAfterUpdate = false; showUpdate("Apex updated — reopening the latest version…"); location.reload();
    });
    updateNow.addEventListener("click", () => {
      if (!updateRegistration?.waiting) return;
      reloadAfterUpdate = true; showUpdate("Updating Apex… please keep this page open.");
      updateRegistration.waiting.postMessage({ type: "SKIP_WAITING" });
    });
    showUpdate("Checking for Apex updates…");
    navigator.serviceWorker.register("./service-worker.js").then((registration) => {
      updateRegistration = registration;
      const waitingWorker = () => {
        if (registration.waiting && navigator.serviceWorker.controller) {
          showUpdate("A new Apex update is ready to install.", true, true); return true;
        }
        return false;
      };
      if (waitingWorker()) return;
      registration.addEventListener("updatefound", () => {
        const worker = registration.installing; if (!worker) return;
        if (navigator.serviceWorker.controller) showUpdate("Downloading an Apex update…");
        worker.addEventListener("statechange", () => {
          if (worker.state === "installed" && navigator.serviceWorker.controller)
            showUpdate("A new Apex update is ready to install.", true, true);
        });
      });
      registration.update().catch(() => {});
      clearTimeout(bannerTimer);
      bannerTimer = setTimeout(() => {
        if (!registration.waiting && !registration.installing) {
          showUpdate("Apex is up to date."); bannerTimer = setTimeout(hideUpdate, 1700);
        }
      }, 900);
    }).catch(() => {
      showUpdate("Apex update checks need an HTTPS connection."); bannerTimer = setTimeout(hideUpdate, 3000);
    });
  }
})();
