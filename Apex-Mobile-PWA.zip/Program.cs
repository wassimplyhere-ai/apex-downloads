using System.Net;
using System.Text.RegularExpressions;

var builder = WebApplication.CreateBuilder(args);
builder.Logging.SetMinimumLevel(LogLevel.Warning);
builder.Services.AddHttpClient("duckduckgo", client =>
{
    client.Timeout = TimeSpan.FromSeconds(18);
    client.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0");
    client.DefaultRequestHeaders.Accept.ParseAdd("text/html");
});
builder.Services.AddHttpClient("dictionary", client =>
{
    client.Timeout = TimeSpan.FromSeconds(14);
    client.DefaultRequestHeaders.UserAgent.ParseAdd("Apex-Mobile/1.0");
});

var app = builder.Build();

app.UseDefaultFiles();
app.UseStaticFiles();

app.MapGet("/api/search", async (string? q, IHttpClientFactory clients, HttpContext context, CancellationToken cancellationToken) =>
{
    if (string.IsNullOrWhiteSpace(q) || q.Length > 240)
        return Results.BadRequest(new { error = "Enter a search phrase up to 240 characters." });

    context.Response.Headers.CacheControl = "no-store";
    try
    {
        var url = $"https://html.duckduckgo.com/html/?q={Uri.EscapeDataString(q.Trim())}";
        using var response = await clients.CreateClient("duckduckgo").GetAsync(url, cancellationToken);
        if (!response.IsSuccessStatusCode)
            return Results.Json(new { error = $"DuckDuckGo returned HTTP {(int)response.StatusCode}. Try again shortly." }, statusCode: StatusCodes.Status502BadGateway);

        var html = await response.Content.ReadAsStringAsync(cancellationToken);
        var results = SearchResults.Parse(html);
        return Results.Ok(new { query = q.Trim(), source = "DuckDuckGo", results });
    }
    catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
    {
        return Results.Json(new { error = "Search timed out. Check your connection and try again." }, statusCode: StatusCodes.Status504GatewayTimeout);
    }
    catch (HttpRequestException)
    {
        return Results.Json(new { error = "Couldn't reach DuckDuckGo. Check your connection and try again." }, statusCode: StatusCodes.Status502BadGateway);
    }
});

app.MapGet("/api/dictionary", async (string? word, IHttpClientFactory clients, HttpContext context, CancellationToken cancellationToken) =>
{
    if (string.IsNullOrWhiteSpace(word) || word.Length > 80 || word.Any(char.IsWhiteSpace))
        return Results.BadRequest(new { error = "Look up one word at a time (up to 80 characters)." });

    context.Response.Headers.CacheControl = "no-store";
    try
    {
        var url = $"https://api.dictionaryapi.dev/api/v2/entries/en/{Uri.EscapeDataString(word.Trim())}";
        using var response = await clients.CreateClient("dictionary").GetAsync(url, cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);
        return Results.Content(body, "application/json; charset=utf-8", statusCode: (int)response.StatusCode);
    }
    catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
    {
        return Results.Json(new { error = "The lookup timed out. Try again in a little while." }, statusCode: StatusCodes.Status504GatewayTimeout);
    }
    catch (HttpRequestException)
    {
        return Results.Json(new { error = "Could not reach the dictionary service. Check your connection." }, statusCode: StatusCodes.Status502BadGateway);
    }
});

app.MapFallbackToFile("index.html");
app.Run();

internal sealed record SearchResult(string Title, string Url, string Host, string Snippet);

internal static class SearchResults
{
    private const RegexOptions Options = RegexOptions.IgnoreCase | RegexOptions.Singleline;
    private static readonly Regex LinkPattern = new("<a\\b(?=[^>]*\\bclass\\s*=\\s*\"[^\"]*\\bresult__a\\b[^\"]*\")[^>]*\\bhref\\s*=\\s*\"(?<url>[^\"]+)\"[^>]*>(?<title>.*?)</a>", Options | RegexOptions.Compiled);
    private static readonly Regex SnippetPattern = new("<a\\b(?=[^>]*\\bclass\\s*=\\s*\"[^\"]*\\bresult__snippet\\b[^\"]*\")[^>]*>(?<snippet>.*?)</a>", Options | RegexOptions.Compiled);
    private static readonly Regex Tags = new("<[^>]*>", RegexOptions.Compiled);
    private static readonly Regex Whitespace = new("\\s+", RegexOptions.Compiled);

    public static List<SearchResult> Parse(string html)
    {
        var links = LinkPattern.Matches(html);
        var snippets = SnippetPattern.Matches(html);
        var results = new List<SearchResult>();

        for (var index = 0; index < links.Count && results.Count < 12; index++)
        {
            var match = links[index];
            var title = Clean(match.Groups["title"].Value);
            var url = ResolveUrl(WebUtility.HtmlDecode(match.Groups["url"].Value));
            if (title.Length == 0 || url is null) continue;
            var snippet = index < snippets.Count ? Clean(snippets[index].Groups["snippet"].Value) : "";
            var host = Uri.TryCreate(url, UriKind.Absolute, out var parsed) ? parsed.Host : "";
            results.Add(new SearchResult(title, url, host, snippet));
        }
        return results;
    }

    private static string Clean(string value) => Whitespace.Replace(WebUtility.HtmlDecode(Tags.Replace(value, " ")), " ").Trim();

    private static string? ResolveUrl(string value)
    {
        var candidate = value.StartsWith("//", StringComparison.Ordinal) ? $"https:{value}" : value;
        if (!Uri.TryCreate(candidate, UriKind.Absolute, out var uri) || uri.Scheme is not ("http" or "https")) return null;
        if (uri.Host.EndsWith("duckduckgo.com", StringComparison.OrdinalIgnoreCase) && uri.AbsolutePath.StartsWith("/l/", StringComparison.Ordinal))
        {
            foreach (var item in uri.Query.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries))
            {
                var pair = item.Split('=', 2);
                if (pair.Length != 2 || pair[0] != "uddg") continue;
                var decoded = WebUtility.UrlDecode(pair[1]);
                if (Uri.TryCreate(decoded, UriKind.Absolute, out var destination) && destination.Scheme is "http" or "https")
                    return destination.ToString();
            }
        }
        return uri.ToString();
    }
}
