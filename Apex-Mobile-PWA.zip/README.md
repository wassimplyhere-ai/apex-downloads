# Apex Mobile & iPad

A responsive browser companion for Apex. It is designed for phone touchscreens, iPad/tablet layouts, and desktop browsers, and can be added to a device home screen as a Progressive Web App (PWA).

The direct mobile package download is [`Apex-Mobile-PWA.zip`](../Apex-Mobile-PWA.zip). It contains the installable web app source; it is not a native APK/IPA. Host it at an HTTPS address, then install from the device browser.

## What's included

- Standard calculator with keyboard input, memory, and a recent-answer history saved locally on each device.
- Scientific functions with degree/radian selection.
- Binary, octal, decimal, and hexadecimal conversion plus bitwise operations.
- Length, mass, and temperature conversion.
- Dictionary lookup with definitions, examples, word lists, and optional pronunciation audio.
- DuckDuckGo web results shown inside Apex; opening a result is optional.
- Six distinct visual styles: Cozy Pink, Ocean Glass, Midnight Neon, Retro Terminal, Warm Paper, and Arcade. Custom palettes let you choose colors and a separate visual style.
- Four selectable button sounds (Soft, Mechanical, Bubble, Arcade), with a mute toggle.
- A service-worker cache keeps the app shell available offline and avoids re-downloading app files on each visit. Apex checks for a new version and shows an update notice with an **Update now** action; updates download in the background and are applied when you choose.

## Run or host it

This project includes a small ASP.NET Core server. It serves the app and provides same-origin API routes for Dictionary and Search, which keeps browser CORS restrictions from blocking results. The server forwards a submitted word to Free Dictionary API and a submitted search query to DuckDuckGo. Those requests happen only after the user chooses Look it up or Search. The API doesn't write queries to a database or log them in app code.

From this folder, run:

```powershell
dotnet run --project Apex.Mobile.csproj
```

For another device to reach it, host the app behind an HTTPS address that both devices can access. The web app is not publicly hosted by this package. Hosting it on HTTPS is also required for the service worker and home-screen installation. Keep the app and `/api` endpoints on the same origin.

## Add to a home screen

- **iPhone or iPad:** open the HTTPS address in Safari, tap **Share**, then **Add to Home Screen**.
- **Android:** open the HTTPS address in Chrome, then choose **Install app** or **Add to Home screen** from the browser menu.

Calculation history and appearance preferences are stored in browser storage on that device; they do not sync between devices. Dictionary and Search require internet access. The mobile app does not include any personal contact details.

## Build

Requires the .NET 10 SDK. To build the web server from this folder:

```powershell
dotnet build Apex.Mobile.csproj -c Release
```

